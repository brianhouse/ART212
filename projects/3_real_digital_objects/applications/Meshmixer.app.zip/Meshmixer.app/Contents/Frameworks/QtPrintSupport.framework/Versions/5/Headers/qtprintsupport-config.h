#define QT_FEATURE_printer 1
#define QT_FEATURE_printdialog 1
#define QT_FEATURE_printpreviewwidget 1
#define QT_FEATURE_printpreviewdialog 1
